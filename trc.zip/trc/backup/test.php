<HTML>
<BODY>

<?php

$file_loc = "/u/web/teler1/clients/";

$file_loc .= $login;

$file_loc .= "/password.txt";

// $file_loc = "/u/web/teler1/Dan/password.txt";

$directory1 = "/u/web/teler1/clients/";
$directory1 .= $login;

$exists = is_dir($directory1) or die ("Unable to find that client ID");
$whattoread = fopen($file_loc, "r");

$file_contents = fread($whattoread, filesize($file_loc));

fclose($whattoread);

if ($password == $file_contents) {
	echo "<center><font face=\"verdana\" size=\"2\"><B>Files for client \"$login\":<BR><BR></font>";
	$directory = "/u/web/teler1/clients/";
	$directory .= $login;
	$handle=opendir($directory);
	while (($file = readdir($handle))!==false) {
	echo "<a href=\"http://www.teleresponse.com/clients/$login/$file\">$file</a><BR>";
	}
	closedir($handle); 

} else {
	echo "password is incorrect.";
}

?>

</BODY>
</HTML>