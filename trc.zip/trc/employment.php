<?

$file_loc = "/u/web/teler1/template.txt";
$whattoread = fopen($file_loc, "r");
$output = fread($whattoread, filesize($file_loc));
fclose($whattoread);


$output = eregi_replace("\[Fullname",$Fullname,$output);
$output = eregi_replace("\[Phone",$Phone,$output);
// $output = eregi_replace("\[18",$18,$output);
$output = eregi_replace("\[under18-age",$under18-age,$output);
$output = eregi_replace("\[sex",$sex,$output);
$output = eregi_replace("\[citizenship",$citizenship,$output);
$output = eregi_replace("\[howdidyouhearabouttrc",$howdidyouhearabouttrc,$output);
$output = eregi_replace("\[Present_Street",$Present_Street,$output);
$output = eregi_replace("\[Present_City",$Present_City,$output);
$output = eregi_replace("\[Present_State",$Present_State,$output);
$output = eregi_replace("\[Present_Zip",$Present_Zip,$output);
$output = eregi_replace("\[Permanent_Street",$Permanent_Street,$output);
$output = eregi_replace("\[Permanent_City",$Permanent_City,$output);
$output = eregi_replace("\[Permanent_State",$Permanent_State,$output);
$output = eregi_replace("\[Permanent_Zip",$Permanent_Zip,$output);
$output = eregi_replace("\[position",$position,$output);
$output = eregi_replace("\[DateCanStart",$DateCanStart,$output);
$output = eregi_replace("\[SalaryDesired",$SalaryDesired,$output);
$output = eregi_replace("\[EmployedNow",$EmployedNow,$output);
$output = eregi_replace("\[Inquire_With_Employer",$Inquire_With_Employer,$output);
$output = eregi_replace("\[Applied_To_TRC_Before",$Applied_To_TRC_Before,$output);
$output = eregi_replace("\[When_Applied_To_TRC_Before",$When_Applied_To_TRC_Before,$output);
$output = eregi_replace("\[Preferred_Shift",$Preferred_Shift,$output);
$output = eregi_replace("\[HS_NameAndLocation",$HS_NameAndLocation,$output);
$output = eregi_replace("\[HS_YearsCompleted",$HS_YearsCompleted,$output);
$output = eregi_replace("\[HS_MajorStudies",$HS_MajorStudies,$output);
$output = eregi_replace("\[College_NameAndLocation",$College_NameAndLocation,$output);
$output = eregi_replace("\[College_YearsCompleted",$College_YearsCompleted,$output);
$output = eregi_replace("\[College_MajorStudies",$College_MajorStudies,$output);
$output = eregi_replace("\[Trade_NameAndLocation",$Trade_NameAndLocation,$output);
$output = eregi_replace("\[Trade_YearsCompleted",$Trade_YearsCompleted,$output);
$output = eregi_replace("\[Trade_MajorStudies",$Trade_MajorStudies,$output);
$output = eregi_replace("\[Skills_Hobbies",$Skills_Hobbies,$output);
$output = eregi_replace("\[Employment_Name_2",$Employment_Name_2,$output);
$output = eregi_replace("\[Employment_Address_2",$Employment_Address_2,$output);
$output = eregi_replace("\[Employment_Position_2",$Employment_Position_2,$output);
$output = eregi_replace("\[Employment_ReasonLeft_2",$Employment_ReasonLeft_2,$output);
$output = eregi_replace("\[Employment_SupervisorName_2",$Employment_SupervisorName_2,$output);
$output = eregi_replace("\[Employment_DatesEmployed_2",$Employment_DatesEmployed_2,$output);
$output = eregi_replace("\[Employment_Phone_2",$Employment_Phone_2,$output);
$output = eregi_replace("\[Employment_Name_3",$Employment_Name_3,$output);
$output = eregi_replace("\[Employment_Address_3",$Employment_Address_3,$output);
$output = eregi_replace("\[Employment_Position_3",$Employment_Position_3,$output);
$output = eregi_replace("\[Employment_ReasonLeft_3",$Employment_ReasonLeft_3,$output);
$output = eregi_replace("\[Employment_SupervisorName_3",$Employment_SupervisorName_3,$output);
$output = eregi_replace("\[Employment_DatesEmployed_3",$Employment_DatesEmployed_3,$output);
$output = eregi_replace("\[Employment_Phone_3",$Employment_Phone_3,$output);
$output = eregi_replace("\[Convicted",$Convicted,$output);
$output = eregi_replace("\[Crime",$Crime,$output);


$newfile = fopen("/u/web/teler1/$Phone.html", "a+");
fwrite($newfile, $output);
fclose($newfile);
echo "Application submitted!\n";

?>